import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

let handler = async (m, { text, conn, command, usedPrefix }) => {
  const fkontak2 = {
    'key': {
      'participants': '0@s.whatsapp.net',
      'remoteJid': 'status@broadcast',
      'fromMe': false,
      'id': 'Halo'
    },
    'message': {
      'contactMessage': {
        'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    },
    'participant': '0@s.whatsapp.net'
  };

const imagurl = 'https://files.catbox.moe/hm0l6b.jpg';
 
 let chname = '⛊  𝚂𝙰𝚈𝙴𝙳-𝚂𝙷𝙰𝚆𝙰𝚉𝙰';
 let chid = '120363316635505389@newsletter';
 
 const mediaMessage = await prepareWAMessageMedia({ image: { url: imagurl }}, { upload: conn.waUploadToServer });

  if (!text) return conn.sendMessage(m.chat, {
    text: `@${m.sender.split('@')[0]} أدخل السؤال أولا يا صديقي\nمثال: ${usedPrefix + command} البوت يحبني`.trim(),
    mentions: [m.sender]
  }, { quoted: fkontak2 });

  let cap = `
╭─────────────────────────╮

┆ السائل: @${m.sender.split('@')[0]}

┆ السؤال: ${command} ${text}

┆ الاجابة: ${['نعم','ممكن','في الاغلب نعم','في الاغلب لا','لا','مستحيل'].getRandom()}

╰─────────────────────────╯
`.trim();

const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: cap },
          footer: { text: wm},
          header: {
            hasMediaAttachment: true,
            imageMessage: mediaMessage.imageMessage
            
          },
        contextInfo: {
        mentionedJid: await conn.parseMention(cap), 
        isForwarded: true, 
        forwardingScore: 1, 
        forwardedNewsletterMessageInfo: {
        newsletterJid: chid, 
        newsletterName: chname, 
        serverMessageId: 100
        },
        externalAdReply: {
        showAdAttribution: true,
          title: "⋄┄〘 التــرفيه 〙┄⋄",
          body: "❲ قســم الترفــيه ❳",
          thumbnailUrl: imagurl,
          mediaUrl: imagurl,
          mediaType: 2,
          sourceUrl: 'https://www.atom.bio/shawaza-2000/',
          renderLargerThumbnail: false
        }
      },
          nativeFlowMessage: {
            buttons: [
              {
              name: 'quick_reply',
              buttonParamsJson: JSON.stringify({
                        display_text: '〘 جــرب مــره اخــرى 〙',
                        id: `${usedPrefix + command} ${text}`
               })
              }
            ]
          }
        }
      }
    }
  }, { userJid: conn.user.jid, quoted: fkontak2 });


 await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

};

handler.help = ['pregunta <texto>?'];
handler.tags = ['kerang'];
handler.command = /^هل$/i;

export default handler;