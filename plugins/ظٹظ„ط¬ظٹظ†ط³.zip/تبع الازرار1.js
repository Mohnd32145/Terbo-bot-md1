import fs from 'fs';
import fetch from 'node-fetch';
import { xpRange } from '../lib/levelling.js';
import PhoneNumber from 'awesome-phonenumber';
import { promises } from 'fs';
import { join } from 'path';

let handler = async (m, { conn, usedPrefix, __dirname, text, isPrems }) => {
    try {
        let vn = './Menu2.jpg';
        let pp = './default.jpg'; // صورة افتراضية إذا لم يتم تعريف imagen4
        let img = await (await fetch('https://telegra.ph/file/example.jpg')).buffer(); // رابط صورة صحيح
        let d = new Date(new Date() + 3600000);
        let locale = 'ar';
        let week = d.toLocaleDateString(locale, { weekday: 'long' });
        let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
        let _uptime = process.uptime() * 1000;
        let uptime = clockString(_uptime);
        let user = global.db.data.users[m.sender] || {};
        let { money = 0, joincount = 0, exp = 0, limit = 0, level = 0, role = 'User' } = user;
        let { min, xp, max } = xpRange(level, global.multiplier || 1);
        let rtotalreg = Object.values(global.db.data.users || {}).filter(user => user.registered).length;
        let more = String.fromCharCode(8206);
        let readMore = more.repeat(850);
        let taguser = '@' + m.sender.split("@s.whatsapp.net")[0];

        let str = `┏━━⊜ *◡̈⃝˼‏👨🏻‍💻˹ ━━|قسم المطور│━━˼👨🏻‍💻˹◡̈⃝*
┇≡ *◡̈⃝🧸📌 تفضل القائمة يا* : *${taguser}*
┇≡ *◡̈⃝⌚📌 وقت التشغيل:* ${uptime}
┇≡ *◡̈⃝⏳📌 التاريخ:* ${date}
┇≡ *◡̈⃝🕊📌 عدد المستخدمين:* ${rtotalreg}
┇≡ *◡̈⃝🧚🏻‍♀️📌 اسم البوت:* 𝑺𝑶𝑵𝑰𝑪🤺🔥
┇≡ *◡̈⃝⚙️📌 المنصة:* replit
┗━━━━━━━━━━⬣

┏━━⊜
❏..◡̈⃝🔕╎❯ .بان⌉
❏..◡̈⃝🔔╎❯ .بانفك⌉
❏..◡̈⃝🚫╎❯ .بانشات⌉
❏..◡̈⃝⭕╎❯ .بانشاتفك⌉
❏..◡̈⃝💎╎❯ .ضيف الماس⌉
❏..◡̈⃝💱╎❯ .ضيف اكسبي⌉
❏..◡̈⃝🔄╎❯ .اعاده⌉
❏..◡̈⃝📤╎❯ .اخرج⌉
❏..◡̈⃝📥╎❯ .ادخل⌉
❏..◡̈⃝👨🏻‍💻╎❯ .تهكير⌉
❏..◡̈⃝⛔╎❯ .البلوكات⌉
❏..◡̈⃝🔰╎❯ .فكالبلوك⌉
❏..◡̈⃝📵╎❯ .بلوك⌉
❐..◡̈⃝🪄❯  .تسريع⌉
❏..◡̈⃝🖱╎❯ .بريم⌉
❏..◡̈⃝👨‍💻╎❯ .الشتات المحظوره⌉
❏..◡̈⃝🍻╎❯ .المحظورين⌉
❏..◡̈⃝🖲╎❯ .حذف_بريم⌉
❏..◡̈⃝🏃‍♂️╎❯ .تسريع البوت⌉
❏..◡̈⃝🗞╎❯ .نشر⌉
❏..◡̈⃝🧨╎❯ .هاك⌉
┗━━━━━━━━━━⬣`.trim();

        let buttonMessage = {
            image: pp,
            caption: str,
            mentions: [m.sender],
            footer: 'Footer هنا', // قدم footer مناسب
            headerType: 4,
            contextInfo: {
                mentionedJid: [m.sender],
                externalAdReply: {
                    showAdAttribution: true,
                    mediaType: 'VIDEO',
                    mediaUrl: null,
                    title: 'Respect-team',
                    body: null,
                    thumbnail: img,
                    sourceUrl: 'https://whatsapp.com/channel/0029ValRCUIFi8xmK9xBOr0I'
                }
            }
        };
        await conn.sendMessage(m.chat, buttonMessage, { quoted: m });

    } catch (err) {
        console.error(err);
        conn.reply(m.chat, '[❗خطأ❗]\n' + err.message, m);
    }
};

handler.command = /^(المشرفين)$/i;
handler.exp = 20;
handler.fail = null;

export default handler;

// تحويل الزمن إلى شكل الساعات والدقائق والثواني
function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}