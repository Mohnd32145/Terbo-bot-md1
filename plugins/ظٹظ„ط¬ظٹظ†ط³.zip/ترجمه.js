import translate from '@vitalets/google-translate-api';


const handler = async (m, {args, usedPrefix, command}) => {


  const msg = `〘 ❗ 〙 ادخل اللغه والنص أولا.\n${usedPrefix + command} <اللغه> <النص>`;
  
  if (!args || !args[0]) return m.reply(msg);
  let lang = args[0];
  let text = args.slice(1).join(' ');
  const defaultLang = 'ar';
  if ((args[0] || '').length !== 2) {
    lang = defaultLang;
    text = args.join(' ');
  }
  if (!text && m.quoted && m.quoted.text) text = m.quoted.text;
  try {
    const result = await translate(`${text}`, {to: lang, autoCorrect: true});
    await m.reply(result.text);
   
    } catch {
      await m.reply('〘 ❗ 〙 حدث خطأ حاول مجدداً.');
    }
  
  
};
handler.command = /^(ترجمه|ترجم|tr)$/i;
export default handler;